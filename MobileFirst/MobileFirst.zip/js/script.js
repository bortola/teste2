




function btnMenu(){
	menu = document.getElementsByClassName("menu");
	menu[0].style.display = "block";
}


function btnFechar(){
	menuFechar = document.getElementsByClassName("menu");
	menuFechar[0].style.display = "none";
}